import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose

class PoseSubscriberNode(Node):
    def __init__(self):
        super().__init__('pose_subscribe')  # Corrected node name
        # Corrected 'create.suscription' to 'create_subscription'
        self.pose_subscriber_ = self.create_subscription(
            Pose,  # Message type
            "turtle1/pose",  # Topic name
            self.pose_callback,  # Callback function
            10  # QoS history depth
        )
        
    def pose_callback(self, msg):
        # Callback function to process Pose data
        self.get_logger().info(
            f"Position -> x: {msg.x}, y: {msg.y}, theta: {msg.theta}"
        )

def main(args=None):
    rclpy.init(args=args)
    node = PoseSubscriberNode()
    
    rclpy.spin(node)  # Keep the node running to process incoming messages
    
    rclpy.shutdown()

if __name__ == '__main__':
    main()
