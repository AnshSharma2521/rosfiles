import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from experiment_interfaqces.msg import Num

class PoseSubscriberNode(Node):
    def __init__(self):
        super().__init__('pose_subscribe')  # Corrected node name
        # Corrected 'create.suscription' to 'create_subscription'
        self.subscription = self.create_subscription(
            Num,  # Message type
            'topic',  # Topic name
            self.listener_callback,  # Callback function
            10  # QoS history depth
        )
        
    def listener_callback(self, msg):
        # Callback function to process Pose data
        self.get_logger().info(
            'I heard:"%d"' % msg.num
        )

def main(args=None):
    rclpy.init(args=args)
    node = PoseSubscriberNode()
    
    rclpy.spin(node)  # Keep the node running to process incoming messages
    
    rclpy.shutdown()

if __name__ == '__main__':
    main()
