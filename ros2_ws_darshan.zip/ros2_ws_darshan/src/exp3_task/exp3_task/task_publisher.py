import rclpy
from rclpy.node import Node
from task3.msg import Birthday

class BirthdayPublisher(Node):
    def __init__(self):
        super().__init__('birthday_publisher')
        self.publisher_ = self.create_publisher(Birthday, 'birthday', 10)
        timer_period = 1  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)

    def timer_callback(self):
        msg = Birthday()
        msg.year = 2004  # Replace with your birth year
        msg.month = 2    # Replace with your birth month
        msg.day = 25     # Replace with your birth day
        self.publisher_.publish(msg)
        
        # Formatting output to match the image
        formatted_msg = f"\nyear: {msg.year}\nmonth: {msg.month}\nday: {msg.day}\n---"
        self.get_logger().info(formatted_msg)

def main(args=None):
    rclpy.init(args=args)
    birthday_publisher = BirthdayPublisher()
    rclpy.spin(birthday_publisher)
    birthday_publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
