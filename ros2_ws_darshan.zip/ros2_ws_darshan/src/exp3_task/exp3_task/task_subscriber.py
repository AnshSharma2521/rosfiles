import rclpy
from rclpy.node import Node
from task3.msg import Birthday

class BirthdaySubscriber(Node):
    def __init__(self):
        super().__init__('birthday_subscriber')
        self.subscription = self.create_subscription(
            Birthday,
            'birthday',
            self.listener_callback,
            10)
        self.subscription  # Prevent unused variable warning

    def listener_callback(self, msg):
        self.get_logger().info(f'I heard: {msg.year}-{msg.month}-{msg.day}')

def main(args=None):
    rclpy.init(args=args)
    birthday_subscriber = BirthdaySubscriber()
    rclpy.spin(birthday_subscriber)
    birthday_subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()