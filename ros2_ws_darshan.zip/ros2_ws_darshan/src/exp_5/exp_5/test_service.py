import rclpy
from rclpy.node import Node
from experiment_interfaces2.srv import AddThreeInts

class MinimalService(Node):
    def __init__(self):
        super().__init__('test_service')
        self.srv = self.create_service(AddThreeInts, 'add_three_ints', self.add_three_ints_callback)
        
    def add_three_ints_callback(self, request, response):
        response.sum = request.a + request.b + request.c
        self.get_logger().info('incoming requests\na: %d b: %d c: %d'
                               % (request.a, request.b, request.c))
        return response
def main(args=None):
    rclpy.init(args=args)
    minimal_service = MinimalService()
    rclpy.spin_once(minimal_service)
    rclpy.shutdown()

if __name__=='__main__':
    main()