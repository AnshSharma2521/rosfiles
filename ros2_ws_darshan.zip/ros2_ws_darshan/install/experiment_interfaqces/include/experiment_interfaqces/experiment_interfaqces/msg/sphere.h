// generated from rosidl_generator_c/resource/idl.h.em
// with input from experiment_interfaqces:msg/Sphere.idl
// generated code does not contain a copyright notice

#ifndef EXPERIMENT_INTERFAQCES__MSG__SPHERE_H_
#define EXPERIMENT_INTERFAQCES__MSG__SPHERE_H_

#include "experiment_interfaqces/msg/detail/sphere__struct.h"
#include "experiment_interfaqces/msg/detail/sphere__functions.h"
#include "experiment_interfaqces/msg/detail/sphere__type_support.h"

#endif  // EXPERIMENT_INTERFAQCES__MSG__SPHERE_H_
