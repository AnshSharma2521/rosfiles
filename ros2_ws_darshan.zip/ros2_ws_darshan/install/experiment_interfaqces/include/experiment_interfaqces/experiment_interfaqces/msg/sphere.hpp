// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXPERIMENT_INTERFAQCES__MSG__SPHERE_HPP_
#define EXPERIMENT_INTERFAQCES__MSG__SPHERE_HPP_

#include "experiment_interfaqces/msg/detail/sphere__struct.hpp"
#include "experiment_interfaqces/msg/detail/sphere__builder.hpp"
#include "experiment_interfaqces/msg/detail/sphere__traits.hpp"

#endif  // EXPERIMENT_INTERFAQCES__MSG__SPHERE_HPP_
