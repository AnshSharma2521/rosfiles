// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXPERIMENT_INTERFAQCES__MSG__NUM_HPP_
#define EXPERIMENT_INTERFAQCES__MSG__NUM_HPP_

#include "experiment_interfaqces/msg/detail/num__struct.hpp"
#include "experiment_interfaqces/msg/detail/num__builder.hpp"
#include "experiment_interfaqces/msg/detail/num__traits.hpp"

#endif  // EXPERIMENT_INTERFAQCES__MSG__NUM_HPP_
