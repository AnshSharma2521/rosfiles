// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXPERIMENT_INTERFACES2__MSG__SPHERE_HPP_
#define EXPERIMENT_INTERFACES2__MSG__SPHERE_HPP_

#include "experiment_interfaces2/msg/detail/sphere__struct.hpp"
#include "experiment_interfaces2/msg/detail/sphere__builder.hpp"
#include "experiment_interfaces2/msg/detail/sphere__traits.hpp"
#include "experiment_interfaces2/msg/detail/sphere__type_support.hpp"

#endif  // EXPERIMENT_INTERFACES2__MSG__SPHERE_HPP_
