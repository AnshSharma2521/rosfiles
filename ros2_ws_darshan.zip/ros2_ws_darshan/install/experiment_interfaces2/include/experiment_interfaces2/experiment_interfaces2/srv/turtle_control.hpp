// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef EXPERIMENT_INTERFACES2__SRV__TURTLE_CONTROL_HPP_
#define EXPERIMENT_INTERFACES2__SRV__TURTLE_CONTROL_HPP_

#include "experiment_interfaces2/srv/detail/turtle_control__struct.hpp"
#include "experiment_interfaces2/srv/detail/turtle_control__builder.hpp"
#include "experiment_interfaces2/srv/detail/turtle_control__traits.hpp"
#include "experiment_interfaces2/srv/detail/turtle_control__type_support.hpp"

#endif  // EXPERIMENT_INTERFACES2__SRV__TURTLE_CONTROL_HPP_
