// generated from rosidl_generator_c/resource/idl.h.em
// with input from experiment_interfaces2:srv/TurtleControl.idl
// generated code does not contain a copyright notice

#ifndef EXPERIMENT_INTERFACES2__SRV__TURTLE_CONTROL_H_
#define EXPERIMENT_INTERFACES2__SRV__TURTLE_CONTROL_H_

#include "experiment_interfaces2/srv/detail/turtle_control__struct.h"
#include "experiment_interfaces2/srv/detail/turtle_control__functions.h"
#include "experiment_interfaces2/srv/detail/turtle_control__type_support.h"

#endif  // EXPERIMENT_INTERFACES2__SRV__TURTLE_CONTROL_H_
