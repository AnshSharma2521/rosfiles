// generated from rosidl_generator_c/resource/idl.h.em
// with input from task3:msg/Birthday.idl
// generated code does not contain a copyright notice

#ifndef TASK3__MSG__BIRTHDAY_H_
#define TASK3__MSG__BIRTHDAY_H_

#include "task3/msg/detail/birthday__struct.h"
#include "task3/msg/detail/birthday__functions.h"
#include "task3/msg/detail/birthday__type_support.h"

#endif  // TASK3__MSG__BIRTHDAY_H_
