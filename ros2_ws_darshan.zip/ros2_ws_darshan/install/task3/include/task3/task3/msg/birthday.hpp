// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TASK3__MSG__BIRTHDAY_HPP_
#define TASK3__MSG__BIRTHDAY_HPP_

#include "task3/msg/detail/birthday__struct.hpp"
#include "task3/msg/detail/birthday__builder.hpp"
#include "task3/msg/detail/birthday__traits.hpp"
#include "task3/msg/detail/birthday__type_support.hpp"

#endif  // TASK3__MSG__BIRTHDAY_HPP_
