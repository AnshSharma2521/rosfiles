// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from task3:msg/Birthday.idl
// generated code does not contain a copyright notice

#ifndef TASK3__MSG__DETAIL__BIRTHDAY__BUILDER_HPP_
#define TASK3__MSG__DETAIL__BIRTHDAY__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "task3/msg/detail/birthday__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace task3
{

namespace msg
{

namespace builder
{

class Init_Birthday_day
{
public:
  explicit Init_Birthday_day(::task3::msg::Birthday & msg)
  : msg_(msg)
  {}
  ::task3::msg::Birthday day(::task3::msg::Birthday::_day_type arg)
  {
    msg_.day = std::move(arg);
    return std::move(msg_);
  }

private:
  ::task3::msg::Birthday msg_;
};

class Init_Birthday_month
{
public:
  explicit Init_Birthday_month(::task3::msg::Birthday & msg)
  : msg_(msg)
  {}
  Init_Birthday_day month(::task3::msg::Birthday::_month_type arg)
  {
    msg_.month = std::move(arg);
    return Init_Birthday_day(msg_);
  }

private:
  ::task3::msg::Birthday msg_;
};

class Init_Birthday_year
{
public:
  Init_Birthday_year()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Birthday_month year(::task3::msg::Birthday::_year_type arg)
  {
    msg_.year = std::move(arg);
    return Init_Birthday_month(msg_);
  }

private:
  ::task3::msg::Birthday msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::task3::msg::Birthday>()
{
  return task3::msg::builder::Init_Birthday_year();
}

}  // namespace task3

#endif  // TASK3__MSG__DETAIL__BIRTHDAY__BUILDER_HPP_
