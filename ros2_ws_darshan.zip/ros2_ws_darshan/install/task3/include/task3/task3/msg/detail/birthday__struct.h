// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from task3:msg/Birthday.idl
// generated code does not contain a copyright notice

#ifndef TASK3__MSG__DETAIL__BIRTHDAY__STRUCT_H_
#define TASK3__MSG__DETAIL__BIRTHDAY__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in msg/Birthday in the package task3.
typedef struct task3__msg__Birthday
{
  int32_t year;
  int32_t month;
  int32_t day;
} task3__msg__Birthday;

// Struct for a sequence of task3__msg__Birthday.
typedef struct task3__msg__Birthday__Sequence
{
  task3__msg__Birthday * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} task3__msg__Birthday__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // TASK3__MSG__DETAIL__BIRTHDAY__STRUCT_H_
