from task3.msg._birthday import Birthday  # noqa: F401
